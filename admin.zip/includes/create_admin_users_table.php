<?php
require_once 'config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS admin_users (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'admin'
    )";
    $pdo->exec($sql);
    echo "Tabla 'admin_users' creada o ya existe.\n";

    // Opcional: Insertar un usuario administrador por defecto si la tabla está vacía
    $stmt = $pdo->query("SELECT COUNT(*) FROM admin_users");
    if ($stmt->fetchColumn() == 0) {
        $default_username = 'admin';
        $default_password = password_hash('admin123', PASSWORD_DEFAULT); // ¡Cambia esta contraseña!
        $stmt = $pdo->prepare("INSERT INTO admin_users (username, password, role) VALUES (?, ?, ?)");
        $stmt->execute([$default_username, $default_password, 'admin']);
        echo "Usuario administrador por defecto ('admin'/'admin123') insertado. ¡CAMBIA LA CONTRASEÑA POR FAVOR!\n";
    }

} catch (PDOException $e) {
    die("Error al crear la tabla 'admin_users': " . $e->getMessage());
}
?>