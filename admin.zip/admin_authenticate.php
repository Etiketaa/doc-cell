<?php
session_start();
require_once 'includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Autenticación exitosa
        $_SESSION['admin_loggedin'] = true;
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['admin_role'] = $user['role'];
        header('Location: admin/index.php');
        exit;
    } else {
        // Autenticación fallida
        header('Location: admin_login.php?error=invalid_credentials');
        exit;
    }
} else {
    header('Location: admin_login.php');
    exit;
}
?>