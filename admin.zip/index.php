<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Obtener los 10 últimos productos agregados para el carrusel
$stmtLatest = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 10");
$latestProducts = $stmtLatest->fetchAll(PDO::FETCH_ASSOC);

// Obtener todos los productos para la búsqueda en tiempo real
$stmtAllProducts = $pdo->query("SELECT * FROM products ORDER BY id DESC");
$allProducts = $stmtAllProducts->fetchAll(PDO::FETCH_ASSOC);

// Obtener categorías únicas para los filtros
$categories = getUniqueCategories($pdo);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bit-House - Catálogo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cascadia+Mono&display=swap" rel="stylesheet">
</head>
<body style="background-color: #f5f5f5;">
    <!-- Header -->
    <header class="p-4" style="background-color: #f5f5f5;">
        <div class="container d-flex flex-column flex-md-row align-items-center justify-content-between text-center text-md-start">
            <div class="d-flex align-items-center gap-3 mb-3 mb-md-0">
                <h1 class="m-0" id="typing-title"></h1>
            </div>
            <button class="btn btn-warning floating-cart" data-bs-toggle="modal" data-bs-target="#cartModal">
        🛒 <span id="cart-count">0</span> items - Ver Carrito
    </button>
            <button class="btn-icon" id="sidebarToggleMobile">
                <i class="bi bi-list"></i>
            </button>
        </div>
    </header>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="btn btn-link text-white" id="sidebarClose">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        
        <ul class="sidebar-nav">
            <li><a href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
            <li><a href="admin_login.php"><i class="bi bi-person-fill-gear"></i> Admin Dashboard</a></li>
        </ul>
        <hr class="sidebar-divider">
        <h5 class="sidebar-title">Categorías</h5>
        <ul class="sidebar-nav category-filters">
            <li>
                <a href="?category=all" class="<?= $category === 'all' ? 'active-category' : '' ?>">
                    Todos
                </a>
            </li>
            <?php foreach ($categories as $cat): ?>
                <li>
                    <a href="?category=<?= urlencode($cat) ?>" class="<?= $category === $cat ? 'active-category' : '' ?>">
                        <?= htmlspecialchars($cat) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- Overlay para el sidebar -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <section class="text-center my-4">
        <div class="cta-banner">
            <h2>Carga tus productos, realiza tu pedido y recibí en tu casa.</h2>
            <p>Envíos gratis a todo Bahía.</p>
        </div>
    </section>

    <!-- Carrusel de Últimos Productos -->
    <section class="container my-5 d-none d-md-block">
        <h2 class="text-center mb-4">Últimos Productos Agregados</h2>
        <div id="latestProductsCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php
                $chunkedProducts = array_chunk($latestProducts, 3); // Mostrar 3 productos por slide
                foreach ($chunkedProducts as $index => $chunk):
                ?>
                <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                    <div class="row justify-content-center">
                        <?php foreach ($chunk as $product):
                        // Asegurarse de que la ruta de la imagen sea correcta
                        $imagePath = htmlspecialchars($product['image']);
                        if (strpos($imagePath, 'img/products/') === false) {
                            $imagePath = 'img/products/' . $imagePath;
                        }
                        ?>
                            <div class="col-md-2 mb-4">
                                <div class="card product-card">
                                    <img src="<?= $imagePath ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                                        <h6>$<?= number_format($product['price'], 2) ?></h6>
                                        <small class="text-muted"><?= htmlspecialchars($product['category']) ?></small>
                                        <div class="mt-2">
                                            <button class="btn btn-info" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#productModal"
                                                onclick="showProductDetails(<?= $product['id'] ?>)">
                                                Más Info
                                            </button>
                                            <button class="btn btn-success" 
                                                onclick="addToCart(<?= $product['id'] ?>)">
                                                Agregar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#latestProductsCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#latestProductsCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>

    <!-- Barra de búsqueda -->
    <section class="container my-4">
        <div class="input-group">
            <input type="text" class="form-control" id="searchInput" placeholder="Buscar productos...">
            <button class="btn btn-outline-secondary" type="button" id="searchButton">Buscar</button>
        </div>
    </section>

    <!-- Productos -->
    <section id="products" class="container mt-3">
        <h2 class="mb-4">Nuestros Productos</h2>
        <div class="row" id="product-list-container">
            <!-- Los productos se cargarán aquí mediante JavaScript -->
        </div>
    </section>

    <!-- Modal de Detalles de Producto -->
    <div class="modal fade" id="productModal">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalProductName"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner" id="carousel-inner"></div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    </div>
                    <p id="modalProductDescription" class="mt-3"></p>
                    <h6>Precio: $<span id="modalProductPrice"></span></h6>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success" onclick="addToCart(selectedProduct.id)">
                        Agregar al carrito
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal del Carrito de Compras -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cartModalLabel">Tu Carrito de Compras</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="cart-items-container"></div>
                    <h4 class="mt-3 text-end">Total: $<span id="cart-total">0.00</span></h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Seguir Comprando</button>
                    <button type="button" class="btn btn-primary" id="confirmOrderButton">Confirmar Pedido</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Pasar todos los productos a JavaScript
        const allProducts = <?= json_encode($allProducts) ?>;
        console.log("Contenido de allProducts:", allProducts);

        const productListContainer = document.getElementById('product-list-container');
        const searchInput = document.getElementById('searchInput');
        const cartCountSpan = document.getElementById('cart-count');
        const cartItemsContainer = document.getElementById('cart-items-container');
        const cartTotalSpan = document.getElementById('cart-total');
        const confirmOrderButton = document.getElementById('confirmOrderButton');

        let cart = []; // Array para almacenar los productos en el carrito
        let selectedProduct = null; // Variable para almacenar el producto seleccionado en el modal de detalles

        function displayProducts(productsToDisplay) {
            productListContainer.innerHTML = ''; // Limpiar productos existentes
            if (productsToDisplay.length === 0) {
                productListContainer.innerHTML = '<p class="text-center w-100">No se encontraron productos.</p>';
                return;
            }

            productsToDisplay.forEach(product => {
                const imagePath = product.image.includes('img/products/') ? product.image : 'img/products/' + product.image;
                const productCard = `
                    <div class="col-4 col-md-3 col-lg-2 mb-4">
                        <div class="card product-card">
                            <img src="${imagePath}" class="card-img-top" alt="${product.name}">
                            <div class="card-body">
                                <h5 class="card-title">${product.name}</h5>
                                <h6>$${parseFloat(product.price).toFixed(2)}</h6>
                                <small class="text-muted">${product.category}</small>
                                <div class="mt-2">
                                    <button class="btn btn-info" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#productModal"
                                        onclick="showProductDetails(${product.id})">
                                        Más Info
                                    </button>
                                    <button class="btn btn-success" 
                                        onclick="addToCart(${product.id})">
                                        Agregar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                productListContainer.innerHTML += productCard;
            });
        }

        // Función para mostrar detalles del producto en el modal
        window.showProductDetails = function(id) {
            console.log("showProductDetails called with id:", id);
            const product = allProducts.find(p => p.id == id); // Usar == para comparación flexible
            if (!product) {
                console.error("Producto no encontrado con ID:", id);
                return;
            }

            selectedProduct = product; // Almacenar el producto completo

            document.getElementById('modalProductName').textContent = product.name;
            document.getElementById('modalProductDescription').textContent = product.description;
            document.getElementById('modalProductPrice').textContent = parseFloat(product.price).toFixed(2);

            const carouselInner = document.getElementById('carousel-inner');
            carouselInner.innerHTML = '';

            const mainImage = product.image.includes('img/products/') ? product.image : 'img/products/' + product.image;

            // Add main image to carousel
            carouselInner.innerHTML += `
                <div class="carousel-item active">
                    <img src="${mainImage}" class="d-block w-100" alt="${product.name}">
                </div>
            `;

            // Add additional images if available
            let images = [];
            try {
                images = product.images ? JSON.parse(product.images) : [];
            } catch (e) {
                console.error("Error parsing product images JSON:", e);
            }

            if (images && images.length > 0) {
                images.forEach(img => {
                    const imgPath = img.includes('img/products/') ? img : 'img/products/' + img;
                    carouselInner.innerHTML += `
                        <div class="carousel-item">
                            <img src="${imgPath}" class="d-block w-100" alt="${product.name}">
                        </div>
                    `;
                });
            }
        };

        // Función para agregar productos al carrito
        window.addToCart = function(id) {
            console.log("addToCart called with id:", id);
            const product = allProducts.find(p => p.id == id); // Usar == para comparación flexible
            if (!product) {
                console.error("Producto no encontrado con ID:", id);
                return;
            }

            const imagePath = product.image.includes('img/products/') ? product.image : 'img/products/' + product.image;

            const existingItem = cart.find(item => item.id === id);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({ id: product.id, name: product.name, price: product.price, image: imagePath, quantity: 1 });
            }
            updateCartDisplay();
        };

        // Función para actualizar la visualización del carrito (contador y modal)
        function updateCartDisplay() {
            const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCountSpan.textContent = totalItems;
            renderCart();
        }

        // Función para renderizar los productos en el modal del carrito
        function renderCart() {
            cartItemsContainer.innerHTML = '';
            let total = 0;

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<p class="text-center">El carrito está vacío.</p>';
            } else {
                cart.forEach(item => {
                    const itemTotal = item.price * item.quantity;
                    total += itemTotal;
                    const cartItemHtml = `
                        <div class="d-flex align-items-center mb-3 border-bottom pb-3">
                            <img src="${item.image}" alt="${item.name}" style="width: 60px; height: 60px; object-fit: cover; margin-right: 15px; border-radius: 5px;">
                            <div class="flex-grow-1">
                                <h5>${item.name}</h5>
                                <p class="mb-0">Cantidad: ${item.quantity} x $${parseFloat(item.price).toFixed(2)}</p>
                            </div>
                            <div class="text-end">
                                <h6>$${itemTotal.toFixed(2)}</h6>
                                <button class="btn btn-sm btn-danger" onclick="removeFromCart(${item.id})">Eliminar</button>
                            </div>
                        </div>
                    `;
                    cartItemsContainer.innerHTML += cartItemHtml;
                });
            }
            cartTotalSpan.textContent = total.toFixed(2);
        }

        // Función para eliminar un producto del carrito
        window.removeFromCart = function(id) {
            cart = cart.filter(item => item.id !== id);
            updateCartDisplay();
        };

        // Función para confirmar el pedido (usa la lógica existente)
        confirmOrderButton.addEventListener('click', function() {
            // Aquí puedes añadir cualquier validación o paso previo antes de completeOrder()
            alert('Pedido confirmado! (Esta es la función completeOrder())'); // Placeholder
            // completeOrder(); // Llama a tu función existente para completar el pedido
            // Cierra el modal del carrito si es necesario
            const cartModal = bootstrap.Modal.getInstance(document.getElementById('cartModal'));
            if (cartModal) {
                cartModal.hide();
            }
        });

        // Función de búsqueda en tiempo real
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            const filteredProducts = allProducts.filter(product => {
                return product.name.toLowerCase().includes(searchTerm) ||
                       product.category.toLowerCase().includes(searchTerm);
            });
            displayProducts(filteredProducts);
        });

        // Mostrar todos los productos al cargar la página inicialmente
        displayProducts(allProducts);

        // Animación de tipeo para el título
        const typingTitle = document.getElementById('typing-title');
        const phrases = ["Bit-House Store", "Code & Commerce", "Dev Deals", "Tech Treasures"];
        let phraseIndex = 0;
        let charIndex = 0;
        let isDeleting = false;

        function typeWriter() {
            const currentPhrase = phrases[phraseIndex];
            let displayedText = currentPhrase.substring(0, charIndex);
            typingTitle.textContent = displayedText;

            if (!isDeleting) {
                charIndex++;
                if (charIndex > currentPhrase.length) {
                    isDeleting = true;
                    setTimeout(typeWriter, 1500); // Pausa antes de borrar
                } else {
                    setTimeout(typeWriter, 100); // Velocidad de tipeo
                }
            } else {
                charIndex--;
                if (charIndex < 0) {
                    isDeleting = false;
                    phraseIndex = (phraseIndex + 1) % phrases.length;
                    setTimeout(typeWriter, 500); // Pausa antes de la siguiente frase
                } else {
                    setTimeout(typeWriter, 50); // Velocidad de borrado
                }
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            typeWriter(); // Iniciar la animación de tipeo

            const sidebarToggleMobile = document.getElementById('sidebarToggleMobile');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const sidebarClose = document.getElementById('sidebarClose');

            sidebarToggleMobile.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarClose.addEventListener('click', () => {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            });

            sidebarOverlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            });
        });
    </script>
</body>
</html>